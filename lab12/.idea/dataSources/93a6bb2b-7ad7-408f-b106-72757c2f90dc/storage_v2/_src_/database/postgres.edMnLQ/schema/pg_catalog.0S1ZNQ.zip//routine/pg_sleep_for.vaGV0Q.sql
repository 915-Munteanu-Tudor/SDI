create function pg_sleep_for(interval) returns void
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function pg_sleep_for(interval) is 'sleep for the specified interval';

alter function pg_sleep_for(interval) owner to postgres;

